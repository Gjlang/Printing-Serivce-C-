﻿namespace OOP_GROUP_29
{
    partial class Updateworker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtEmail1 = new System.Windows.Forms.TextBox();
            this.txtPassword1 = new System.Windows.Forms.TextBox();
            this.txtPhone1 = new System.Windows.Forms.TextBox();
            this.txtName1 = new System.Windows.Forms.TextBox();
            this.btnUpdateEmail1 = new System.Windows.Forms.Button();
            this.btnUpdatePassword1 = new System.Windows.Forms.Button();
            this.btnUpdatePhone1 = new System.Windows.Forms.Button();
            this.btnUpdateUserName1 = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelUserName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(153, 343);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 48);
            this.button1.TabIndex = 41;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtEmail1
            // 
            this.txtEmail1.Location = new System.Drawing.Point(250, 281);
            this.txtEmail1.Name = "txtEmail1";
            this.txtEmail1.Size = new System.Drawing.Size(200, 22);
            this.txtEmail1.TabIndex = 40;
            // 
            // txtPassword1
            // 
            this.txtPassword1.Location = new System.Drawing.Point(250, 241);
            this.txtPassword1.Name = "txtPassword1";
            this.txtPassword1.Size = new System.Drawing.Size(200, 22);
            this.txtPassword1.TabIndex = 39;
            // 
            // txtPhone1
            // 
            this.txtPhone1.Location = new System.Drawing.Point(250, 201);
            this.txtPhone1.Name = "txtPhone1";
            this.txtPhone1.Size = new System.Drawing.Size(200, 22);
            this.txtPhone1.TabIndex = 38;
            // 
            // txtName1
            // 
            this.txtName1.Location = new System.Drawing.Point(250, 161);
            this.txtName1.Name = "txtName1";
            this.txtName1.Size = new System.Drawing.Size(200, 22);
            this.txtName1.TabIndex = 37;
            // 
            // btnUpdateEmail1
            // 
            this.btnUpdateEmail1.Location = new System.Drawing.Point(500, 271);
            this.btnUpdateEmail1.Name = "btnUpdateEmail1";
            this.btnUpdateEmail1.Size = new System.Drawing.Size(150, 30);
            this.btnUpdateEmail1.TabIndex = 36;
            this.btnUpdateEmail1.Text = "Update Email";
            this.btnUpdateEmail1.UseVisualStyleBackColor = true;
            this.btnUpdateEmail1.Click += new System.EventHandler(this.UpdateEmail_Click);
            // 
            // btnUpdatePassword1
            // 
            this.btnUpdatePassword1.Location = new System.Drawing.Point(500, 231);
            this.btnUpdatePassword1.Name = "btnUpdatePassword1";
            this.btnUpdatePassword1.Size = new System.Drawing.Size(150, 30);
            this.btnUpdatePassword1.TabIndex = 35;
            this.btnUpdatePassword1.Text = "Update Password";
            this.btnUpdatePassword1.UseVisualStyleBackColor = true;
            this.btnUpdatePassword1.Click += new System.EventHandler(this.UpdatePassword_Click);
            // 
            // btnUpdatePhone1
            // 
            this.btnUpdatePhone1.Location = new System.Drawing.Point(500, 191);
            this.btnUpdatePhone1.Name = "btnUpdatePhone1";
            this.btnUpdatePhone1.Size = new System.Drawing.Size(150, 30);
            this.btnUpdatePhone1.TabIndex = 34;
            this.btnUpdatePhone1.Text = "Update Phone";
            this.btnUpdatePhone1.UseVisualStyleBackColor = true;
            this.btnUpdatePhone1.Click += new System.EventHandler(this.UpdatePhone_Click);
            // 
            // btnUpdateUserName1
            // 
            this.btnUpdateUserName1.Location = new System.Drawing.Point(500, 151);
            this.btnUpdateUserName1.Name = "btnUpdateUserName1";
            this.btnUpdateUserName1.Size = new System.Drawing.Size(150, 30);
            this.btnUpdateUserName1.TabIndex = 33;
            this.btnUpdateUserName1.Text = "Update User Name";
            this.btnUpdateUserName1.UseVisualStyleBackColor = true;
            this.btnUpdateUserName1.Click += new System.EventHandler(this.UpdateUserName_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(184, 60);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(405, 42);
            this.labelTitle.TabIndex = 32;
            this.labelTitle.Text = "Update Worker Profile";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(150, 281);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(41, 16);
            this.labelEmail.TabIndex = 31;
            this.labelEmail.Text = "Email";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(150, 241);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(67, 16);
            this.labelPassword.TabIndex = 30;
            this.labelPassword.Text = "Password";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(150, 201);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(46, 16);
            this.labelPhone.TabIndex = 29;
            this.labelPhone.Text = "Phone";
            // 
            // labelUserName
            // 
            this.labelUserName.AutoSize = true;
            this.labelUserName.Location = new System.Drawing.Point(150, 161);
            this.labelUserName.Name = "labelUserName";
            this.labelUserName.Size = new System.Drawing.Size(76, 16);
            this.labelUserName.TabIndex = 28;
            this.labelUserName.Text = "User Name";
            // 
            // Updateworker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtEmail1);
            this.Controls.Add(this.txtPassword1);
            this.Controls.Add(this.txtPhone1);
            this.Controls.Add(this.txtName1);
            this.Controls.Add(this.btnUpdateEmail1);
            this.Controls.Add(this.btnUpdatePassword1);
            this.Controls.Add(this.btnUpdatePhone1);
            this.Controls.Add(this.btnUpdateUserName1);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelUserName);
            this.Name = "Updateworker";
            this.Text = "Updateworker";
            this.Load += new System.EventHandler(this.Updateworker_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtEmail1;
        private System.Windows.Forms.TextBox txtPassword1;
        private System.Windows.Forms.TextBox txtPhone1;
        private System.Windows.Forms.TextBox txtName1;
        private System.Windows.Forms.Button btnUpdateEmail1;
        private System.Windows.Forms.Button btnUpdatePassword1;
        private System.Windows.Forms.Button btnUpdatePhone1;
        private System.Windows.Forms.Button btnUpdateUserName1;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelUserName;
    }
}