﻿using System;
using System.Windows.Forms;

namespace OOP_GROUP_29
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Loginpage login_Page = new Loginpage();
            login_Page.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Add functionality here if needed
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
