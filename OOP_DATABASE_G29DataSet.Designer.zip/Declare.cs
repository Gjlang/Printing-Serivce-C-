﻿namespace OOP_GROUP_29
{
    public static class Declare
    {
        public static string ConnectionString { get; } = "Data Source=LAPTOP-13KUA0E2\\SQLEXPRESS;Initial Catalog=OOP_DATABASE_G29;Integrated Security=True;TrustServerCertificate=True";
    }
}
