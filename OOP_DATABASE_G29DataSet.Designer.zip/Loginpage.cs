﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace OOP_GROUP_29
{
    public partial class Loginpage : Form
    {
        public Loginpage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string username = textBox1.Text;
                string password = textBox2.Text;

                // Use the declared connection string
                string connectionString = Declare.ConnectionString;

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // SQL query to check username and password
                    string query = "SELECT Role FROM Register WHERE Username = @username AND Password = @password";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                // Retrieve the user role
                                string role = dr["Role"].ToString();

                                // Navigate to the appropriate form based on the user role
                                MessageBox.Show("Login successful!");

                                switch (role)
                                {
                                    case "Admin":
                                        AdminForm adminForm = new AdminForm();
                                        adminForm.Show();
                                        break;
                                    case "Manager":
                                        ManagerForm managerForm = new ManagerForm();
                                        managerForm.Show();
                                        break;
                                    case "Worker":
                                        WorkerForm workerForm = new WorkerForm();
                                        workerForm.Show();
                                        break;
                                    case "Customer":
                                        CustomerForm customerForm = new CustomerForm(username); // Pass username here
                                        customerForm.Show();
                                        break;
                                    default:
                                        MessageBox.Show("Invalid role!");
                                        break;
                                }

                                this.Hide();
                            }
                            else
                            {
                                // If the user doesn't exist, display an error message
                                MessageBox.Show("Invalid username or password. Please try again.");
                                textBox2.Clear();
                                textBox1.Focus();
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Log exception
                // For example, you could use MessageBox to show the error message for now
                MessageBox.Show("An error occurred accessing the database: " + ex.Message);
            }
        }

        private void Loginpage_Load(object sender, EventArgs e)
        {

        }
    }
}
