﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_GROUP_29.Customer
{
    public partial class Confirmationpage : Form
    {
        public Confirmationpage()
        {
            InitializeComponent();
        }

        private void Confirmationpage_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ooP_DATABASE_G29DataSet1.Requests' table. You can move, or remove it, as needed.
            this.requestsTableAdapter.Fill(this.ooP_DATABASE_G29DataSet1.Requests);

        }
    }
}
